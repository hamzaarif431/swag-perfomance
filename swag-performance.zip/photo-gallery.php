<?php
    include 'includes/header.php';
    $page = 'home';
?>
<main>
    <section class="sec-banner">
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12">
                    <div class="banner-desc">
                        <h3 class="banner-h">photo gallery</h3>
                        <p class="banner-p">Lorem Ipsum Dolor Sit Amet, Consectetur Adipiscing Elit, Sed Do Eiusmod
                            Tempor<br> Incididunt Ut Labore Et Dolore Magna Aliqua. Ut Enim Ad Minim Veniam</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="sec-photo-gallery">
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 col-xxl-6">
                    <div class="card gallery-card">
                        <div class="gallery-img">
                            <img src="images/photo-gallery/gl1.png" class="img-fluid gallery-thumb" alt="">
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 col-xxl-6">
                    <div class="card gallery-card">
                        <div class="gallery-img">
                            <img src="images/photo-gallery/gl2.png" class="img-fluid gallery-thumb" alt="">
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 col-xxl-4">
                    <div class="card gallery-card">
                        <div class="gallery-img">
                            <img src="images/photo-gallery/gl3.png" class="img-fluid gallery-thumb" alt="">
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 col-xxl-4">
                    <div class="card gallery-card">
                        <div class="gallery-img">
                            <img src="images/photo-gallery/gl4.png" class="img-fluid gallery-thumb" alt="">
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 col-xxl-4">
                    <div class="card gallery-card">
                        <div class="gallery-img">
                            <img src="images/photo-gallery/gl5.png" class="img-fluid gallery-thumb" alt="">
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 col-xxl-6">
                    <div class="card gallery-card">
                        <div class="gallery-img">
                            <img src="images/photo-gallery/gl6.png" class="img-fluid gallery-thumb" alt="">
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 col-xxl-6">
                    <div class="card gallery-card">
                        <div class="gallery-img">
                            <img src="images/photo-gallery/gl7.png" class="img-fluid gallery-thumb" alt="">
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 col-xxl-4">
                    <div class="card gallery-card">
                        <div class="gallery-img">
                            <img src="images/photo-gallery/gl8.png" class="img-fluid gallery-thumb" alt="">
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 col-xxl-4">
                    <div class="card gallery-card">
                        <div class="gallery-img">
                            <img src="images/photo-gallery/gl9.png" class="img-fluid gallery-thumb" alt="">
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 col-xxl-4">
                    <div class="card gallery-card">
                        <div class="gallery-img">
                            <img src="images/photo-gallery/gl10.png" class="img-fluid gallery-thumb" alt="">
                        </div>
                    </div>
                </div>

            </div>
            
        </div>
    </section>
</main>

<?php
    include 'includes/footer.php';
    $page = 'home';
?>