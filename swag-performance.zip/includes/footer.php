<!--footer start-->
      <!-- footer css start -->
      <footer class="">
         <div class="container">
            <div class="row">
               <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 col-xxl-3">
                  <div class="footerimg">
                     <a href="index.php"><img src="images/footer-logo.png" class="img-fluid" alt="img"></a>

                  </div>
                  <div class="footericon">
                     <h5>Follow us</h5>
                     <ul class="p-0">
                        <li><a href="javascript:"><i class="fab fa-facebook-f"></i></a></li>
                         <li><a href="javascript:"><i class="fab fa-instagram"></i></a></li>
                          <li><a href="javascript:"><i class="fab fa-twitter"></i></a></li>
                           
                     </ul>
                  </div>
               </div>
                 <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 col-xxl-3">
                    <div class="footerlist">
                       <h5>Performance</h5>
                       <ul>
                          <li><a href="about-us.php">About Us</a></li>
                           <li><a href="become-dealer.php">Become a Dealer</a></li>
                            <li><a href="catalog.php">Catalog</a></li>
                             <li><a href="events.php">Events</a></li>
                              <li><a href="install-instruction.php">Install Insturctions</a></li>
                               <li><a href="javascript:">Tech Forms</a></li>
                                <li><a href="warranties.php">Warranties</a></li>
                       </ul>
                    </div>
                    <div class="payimg">
                       <img src="images/pay-img.png" class="img-fluid" alt="img">
                    </div>
                 </div>
                  <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 col-xxl-3">
                     <div class="footerlist">
                       <h5>Products</h5>
                       <ul>
                          <li><a href="javascript:">Diesel</a></li>
                           <li><a href="javascript:">Converters</a></li>
                            <li><a href="javascript:">Parts</a></li>
                             <li><a href="javascript:">Rebuild Kits</a></li>
                              <li><a href="javascript:">Transmission</a></li>
                               <li><a href="javascript:">Off road</a></li>
                                <li><a href="javascript:">Converters</a></li>
                       </ul>
                    </div>
                  </div>
                  <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 col-xxl-3">
                     <div class="footerlist">
                       <h5>Support</h5>
                       <ul>
                          <li><a href="contact-us.php">Contact Us</a></li>
                           <li><a href="core-information.php">Core Information</a></li>
                            <li><a href="login.php">Login</a></li>
                             <li><a href="return-policy.php">Orders & Returns</a></li>
                              <li><a href="sign-up.php">Register</a></li>
                               <li><a href="javascript:">Sitemap</a></li>
                               
                       </ul>
                    </div>
                  </div>
            </div>
         </div>
      </footer>
      <!-- footer css end -->

      <!-- copyrightsec start -->
      <section class="copysec">
         <div class="container">
            <div class="row">
               <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12">
                  <div class="copytext">
                     <p> Copyright © 2021 companynamehere. All Rights Reserved.</p>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- copyrightsec end -->
<!--footer close-->

      <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
      <script src="js/bootstrap.js"></script>
      <script src="js/owl.carousel.min.js"></script>
      <script type="text/javascript" src="slick/slick.min.js"></script>
      <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
      <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
      <script src="js/wow.min.js"></script>
      <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>